const PDFDocument = require("pdfkit");
const fs = require("fs");

export const GenerateBrgyClearance = (
  fullname,
  status,
  animal,
  color,
  age,
  sex,
  issueDate
) => {
  const doc = new PDFDocument({
    size: "A4",
    margins: { top: 40, bottom: 40, left: 50, right: 50 },
  });

  // Define the file path to save the PDF
  const filePath = `../src/assets/pdf/[Certificate of Indigency ] ${issueDate}-${fullname}.pdf`;

  // Stream the PDF into a file
  doc.pipe(fs.createWriteStream(filePath));

  // Header section
  doc.image("../src/assets/UX.png", 90, 20, { width: 100 }); // adjust path to your logo image
  doc.image("../src/assets/UX2.png", 400, 20, { width: 100 }); // adjust path to your logo image
  doc.fontSize(12).font("Helvetica-Bold");
  doc.text("Republic of the Philippines", { align: "center" });
  doc.text("Province of Antique", { align: "center" });
  doc.text("Municipality of Belison", { align: "center" });
  doc.text("BARANGAY SALVACION", { align: "center", Textcolor: "red"});
  doc.text("OFFICE OF THE PUNONG BARANGAY", { align: "center" });
  doc.text("BARANGAY INDIGENCY", { align: "center" });
  doc.moveDown(1);

  // Official list on the left
  doc.fontSize(7).font("Helvetica-Bold");
  doc.text("SALVACION BARANGAY COUNCIL", 50, 130);
  doc.font("Helvetica");
  doc.text("Hon.Domingo T. Seraspe", 50, 150);
  doc.text("Punong Barangay", 50, 162,{ color: "blue" });
  doc.moveDown(0.5);
  doc.text("Hon. Rex Dela Pena", 50, 180);
  doc.text("Chairman, Committee on Infrastructure", 50, 192);
  doc.text("Hon. Edmon D. Dionesio", 50, 204);
  doc.text("Committee on Peace and Order", 50, 222);
  doc.text("Hon.Salvacion L. Seraspe", 50, 234);
  doc.text("Chairman, Committee on Health Women And Family", 50, 252);
  doc.text("Hon. Jerry D. Seraspe", 50, 264);
  doc.text("Chairman, Committee On Rules, Privileges and human Rights", 50, 282);
  doc.text("Hon.Ma.Narisa Lacson", 50, 294);
  doc.text("Chairman, Committee on Budget, Finance and Appropriations", 50, 312);
  doc.text("Hon. Elsa.E.Dimamay", 50, 324);
  doc.text("Chairman, Committee on Education, NGO's and Cooperative", 50, 342);
  doc.text("Hon. Mary Jane S.Mondejar", 50, 354);
  doc.text("Chairman, Committee on Sports and Youth Development", 50, 372);
  doc.text("Mrs. Jhoma Rose A. Escote", 50, 384);
  doc.text("Barangay Secretary", 50, 402);
  doc.text("Mrs.Jonalyn O.Salcedo", 50, 414);
  doc.text("Barangay Treasurer", 50, 426);
  // doc.text("", 50, 444);
  // doc.text("", 50, 456);
  // doc.text("", 50, 474);
  // doc.text("", 50, 486);
  doc.moveDown(1);

  // Certification content on the right
  doc.fontSize(12).font("Helvetica-Bold");
  doc.text("BARANGAY CERTIFICATION", 250, 140);
  doc.moveDown(1);

  doc.fontSize(11).font("Helvetica");
  doc.text("TO WHOM IT MAY CONCERN:", 250, 180);
  doc.moveDown(1);

  doc.text(
    `This is to certify that, ${fullname}. of legal age, married and  resident of Barangay Salvacion, Belison, Antique She or He is an indigent person. Her income is insufficient to sustain their daily needs. ${animal} with the following description:`,
    250,
    200,
    { align: "justify", width: 300 }
  );
  doc.text(
    `Issued this ${issueDate} at Barangay Salvacion, Belison, Antique, Philippines.`,
    250,
    350,
    { align: "justify", width: 300 }
  );
  doc.text(
    `This certification is being issued upon the request of the above interested party to be used for whatever legal purpose it may serve.`,
    250,
    280,
    { align: "justify", width: 300 }
  );
  // doc.moveDown(1);
  // doc.text(`Color: ${color}`, 250, 270);
  // doc.text(`Age: ${age} Year Olds`, 250, 290);
  // doc.text(`Sex: ${sex}`, 250, 310);
  // doc.moveDown(1);
 
  doc.moveDown(1);

  doc.text(`DOMINGO T. SERASPE`, 250, 470, { align: "right" });
  doc.text(`Punong Barangay`, 250, 490, { align: "right" });
  doc.moveDown(1);

  doc.text(`Fees paid under: O.R. No. 3354251`, 250, 580);
  doc.text(`Issued on ${issueDate}`, 250, 600);
  doc.text(`Issued at Salvacion, Belison, Antique`, 250, 620);
  doc.text(`In the amount of ₱50.00 only`, 250, 630);
  doc.moveDown(1);

  // Finalize the PDF and end the stream
  doc.end();

  console.log(`PDF saved to ${filePath}`);
};

export default { GenerateBrgyClearance };
