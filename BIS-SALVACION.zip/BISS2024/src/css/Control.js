// notification-backdrop.js
$('#notification-backdrop').modal('show');