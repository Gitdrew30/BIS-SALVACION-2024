import { useEffect, useState } from "react";
import Bell from "../assets/Logo/Belly.png";
import { Loop, Table, Tick } from "../lib";
import axios from "axios";
import { Body, Card } from "../lib/components/Card";

export default function Notifications() {
  useEffect(() => {
    Tick(GetNotificationByAccounts);
  }, []);


  const [data, sendData] = useState({});

  const GetNotificationByAccounts = async () => {
    const res = await axios("http://localhost:4435/notifications/accounts");
    sendData(res.data);
  };

  const GetNotificationByDocuments = async () => {
    const res = await axios("http://localhost:4435/notifications/documents");
    sendData(res.data);
  };

  console.log(data.length)

  return (
    <Table.Row props="text-center">
      <Table.Col props="col-sm-3">
        <div className="nav nav-tabs" role="tablist">
          <div class="card w-80 mb-4 mt-12 p-2  bg-sky-200">
            <div class="card-body">
              <b>
                <h5 class="card-title text-center p-4">Manage Residents</h5>
              </b>
              <p class="card-text">Transaction/History</p>
            </div>
            <div className="card-footer text-center">
              <a
                href="#"
                class="btn btn-primary"
                data-bs-toggle="tab"
                data-bs-target="#n1"
                role="tab"
                aria-selected="true"
              >
                VIEW
              </a>
            </div>
          </div>

          <div class="card w-80 mb-55 p-2 bg-sky-200">
            <div class="card-body">
              <b>
                <h5 class="card-title text-center p-4">Create Documents</h5>
              </b>
              <p class="card-text">Transaction/History</p>
            </div>
            <div className="card-footer text-center">
              <a
                href="#"
                class="btn btn-primary"
                data-bs-toggle="tab"
                data-bs-target="#n2"
                role="tab"
                aria-selected="false"
              >
                VIEW
              </a>
            </div>
          </div>

          <div class="card w-80 mt-8 p-2 bg-sky-200">
            <div class="card-body ">
              <b>
                <h5 class="card-title text-center p-4">Any</h5>
              </b>
              <p class="card-text">Transaction/History</p>
            </div>
            <div className="card-footer text-center">
              <a href="#" class="btn btn-primary">
                VIEW
              </a>
            </div>
          </div>
        </div>
      </Table.Col>

      <Table.Col props="col-sm-5 mt-56">
        <div className="tab-content">
          <div
            id="n1"
            className="tab-pane fade show active"
            role="tabpanel"
            tabIndex={0}
          >
            <Table.Row props="mx-10">
              <Loop repeat={data.length}>
                {(index) => <div key={index} className="card col-sm-8 mb-3">
                  <div className="card-body text-left">
                      {data[index].message}
                    </div>
                  </div>}
              </Loop>
            </Table.Row>
          </div>
          <h1>Notify:
          <div id="n2" className="tab-pane fade text-green-500 text-xl font-semibold" role="tabpanel" tabIndex={0}>
            Doucment has been created by personnel.
          </div>
          </h1>
        </div>
      </Table.Col>
    </Table.Row>
  );
}
