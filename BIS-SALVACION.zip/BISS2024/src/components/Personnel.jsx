import {
  Button,
  Card,
  Container,
  Navbar,
  Strings,
  Table,
  Text,
} from ".././lib";
import DocumentGenerator from "./Pages/Generate.jsx";
import ManageResidents from "./Pages/MangeRes.jsx";
import ManageRequests from "./Pages/ManageReq.jsx";
import ManageTransactions from "./Pages/Transactions.jsx";
import { useNavigate } from "react-router-dom";
import "../css/Instant.css";  
import Circle from "../assets/UX.png";
import logop1 from "../assets/Logo/document.png";
import logop2 from "../assets/Logo/resident.png";
import logop3 from "../assets/Logo/request.png";
import logop4 from "../assets/Logo/transaction.png";
import Notifications from "./Notifications.jsx";
import Notif from "../assets/Logo/Belly.png";
import Documents from "./Documents.jsx";

export default function Personnel() {
  const navigate = useNavigate();
  return (
    <div className=" min-h-screen lightsteelblue ">
      <>
        <Navbar.Navbar props="info fixed-top">
          <img src={Circle} width={45} className=" fixed-top ml-2 top-1" />
          <div className="container-fluid ml-14">
            <Navbar.Brand label="You are here in Personnel!" />
            <div className="btn2">
              <div
                className="button hover:bg-sky-800 hover:rounded-md p-1 text-white inline-block mx-auto cursor-pointer"
                onClick={() => navigate("/login")}
              >
                LOGOUT
              </div>
            </div>
          </div>
        </Navbar.Navbar>

        <Table.Row props="py-5 px-20">
          <Table.Col props="col-sm-3 py-24">
            <Card.Card>
              <Card.Header props="text-center p-3">
                <img src={Circle} width={100} className="block ml-auto mr-auto"/>
              </Card.Header>

              <Card.Body>
                <ul
                  class="nav nav-pills mb-3 gap-10 grid w-full justify-items-center"
                  id="pills-tab"
                  role="tablist"
                >
                  <li class="nav-item excite" role="presentation">
                    <div
                      class="nav-link flex justify-items-end items-center"
                      id="pills-home-tab"
                      data-bs-toggle="pill"
                      data-bs-target="#page1"
                      type="button"
                      role="tab"
                      aria-controls="pills-home"
                      aria-selected="true"
                    >
                      <img
                        src={logop2}
                        width={48}
                        height={48}
                        className="mx-3"
                      />
                      <h1 className="text-3xl">Manage Residents</h1>
                    </div>
                  </li>
                  <li class="nav-item excite" role="presentation">
                    <div
                      class="nav-link flex justify-items-end items-center"
                      id="pills-home-tab"
                      data-bs-toggle="pill"
                      data-bs-target="#page2"
                      type="button"
                      role="tab"
                      aria-controls="pills-home"
                      aria-selected="true"
                    >
                      <img
                        src={Notif}
                        width={48}
                        height={48}
                        className="mx-3"
                      />
                      <h1 className="text-3xl">Create Documents</h1>
                    </div>
                  </li>
                  <li class="nav-item excite" role="presentation">
                    <div
                      class="nav-link flex items-center"
                      id="pills-home-tab"
                      data-bs-toggle="pill"
                      data-bs-target="#page3"
                      type="button"
                      role="tab"
                      aria-controls="pills-home"
                      aria-selected="true"
                    >
                      <img
                        src={logop1}
                        width={48}
                        height={48}
                        className="mx-3"
                      />
                      <h1 className="text-3xl">Notifcations</h1>
                    </div>
                  </li>
                </ul>
              </Card.Body>
            </Card.Card>
          </Table.Col>

          <Table.Col props="col-sm-9 p-5">
            <div class="tab-content" id="pills-tabContent">
              <div
                class="tab-pane fade show active"
                id="page1"
                role="tabpanel"
                aria-labelledby="pills-home-tab"
                tabindex="0"
              >
                <ManageResidents />
              </div>
              <div
                class="tab-pane fade"
                id="page2"
                role="tabpanel"
                aria-labelledby="pills-profile-tab"
                tabindex="0"
              >
                <DocumentGenerator /> 
              </div>
              <div
                class="tab-pane fade"
                id="page3"
                role="tabpanel"
                aria-labelledby="pills-contact-tab"
                tabindex="0"
              >
                <Notifications />
              </div>
            </div>
          </Table.Col>
        </Table.Row>
      </>
    </div>
  );
}
