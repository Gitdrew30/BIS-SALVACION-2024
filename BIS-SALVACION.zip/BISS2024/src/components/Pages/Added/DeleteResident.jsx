import axios from "axios";
import { Button, Page } from "../../../lib";

let id = null;

export function SetResidentId(idXYZ) {
  return (id = idXYZ);
}

async function RemoveResident() {
    let data = {
        resident_id: id
    }

    Notify("The admin/personnel removed resident", "Accounts");

    await axios.post('http://localhost:4435/residents/delete', data);
}

function Footer() {
  return (
    <>
      <Button label="Cancel" props="btn btn-secondary" dismiss="modal" />
      <Button label="Done" props="btn btn-danger" dismiss="modal" click={() => RemoveResident()} />
    </>
  );
}

export default function DeleteResident() {
  return (
    <Page id="deleteUser" footerChildren={<Footer />}>
      <h1>Delete Resident</h1>
    </Page>
  );
}
