import axios from "axios";
import { Button, Page } from "../../../lib";
import Notify from "../../Notify";

let fname = null;
let mname = null;
let lname = null;
let birthday = null;
let sex = null;
let occupation = null;
let civilStatus = null;
let id = null;

export function SetResidentInfo(
  fnameXYZ,
  mnameXYZ,
  lnameXYZ,
  birthdayXYZ,
  sexXYZ,
  occupationXYZ,
  civilStatusXYZ,
  idXYZ
) {
  fname = fnameXYZ;
  mname = mnameXYZ;
  lname = lnameXYZ;
  birthday = birthdayXYZ;
  sex = sexXYZ;
  occupation = occupationXYZ;
  civilStatus = civilStatusXYZ;
  id = idXYZ;
}

async function ModifyResident() {
  let fname = document.querySelector("#editFname");
  let mname = document.querySelector("#editMname");
  let lname = document.querySelector("#editLname");
  let birthday = document.querySelector("#editBirthday");
  let sex = document.querySelector("#editSex");
  let occupation = document.querySelector("#editOccupation");
  let civilStatus = document.querySelector("#editCivilStatus");

  const data = {
    resident_firstname: fname.value,
    resident_middlename: mname.value,
    resident_lastname: lname.value,
    resident_birthday: 20030101,
    resident_sex: sex.value,
    resident_occupation: occupation.value,
    resident_civil_status: civilStatus.value,
    resident_id: id,
  };

  Notify("The admin/personnel edited a resident", "Accounts");  

  await axios.put("http://localhost:4435/residents", data);
}

function Footer() {
  return (
    <>
      <Button label="Cancel" props="btn-secondary" dismiss="modal" />
      <Button
        label="Done"
        props="btn-primary"
        dismiss="modal"
        click={() => ModifyResident()}
      />
    </>
  );
}

export default function EditResident() {
  return (
    <Page id="editResident" footerChildren={<Footer />}>
      <div className="row">
        <div className="col-sm-4 mb-3">
          <input
            type="text"
            id="editFname"
            className="form-control"
            placeholder="Firtsname"
            defaultValue={fname}
          />
        </div>

        <div className="col-sm-4 mb-3">
          <input
            type="text"
            id="editMname"
            className="form-control"
            placeholder="Middlename"
            defaultValue={mname}
          />
        </div>

        <div className="col-sm-4 mb-3">
          <input
            type="text"
            id="editLname"
            className="form-control"
            placeholder="Lastname"
            defaultValue={lname}
          />
        </div>

        <div className="col-sm-4 mb-3">
          <input
            type="text"
            id="editAge"
            type="date"
            className="form-control"
            placeholder="Birthday"
            defaultValue={birthday}
          />
        </div>

        <div className="col-sm-4 mb-3">
          <input
            type="text"
            id="editSex"
            className="form-control"
            placeholder="Sex"
            defaultValue={sex}
          />
        </div>

        <div className="col-sm-4 mb-3">
          <input
            type="text"
            id="editOccupation"
            className="form-control"
            placeholder="Occupation"
            defaultValue={occupation}
          />
        </div>

        <div className="col-sm-4 mb-3">
          <input
            type="text"
            id="editCivilStatus"
            className="form-control"
            placeholder="Civil Status"
            defaultValue={civilStatus}
          />
        </div>
      </div>
    </Page>
  );
}
