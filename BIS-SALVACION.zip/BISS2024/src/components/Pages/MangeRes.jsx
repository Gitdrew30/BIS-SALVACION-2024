import React, { useState, useEffect } from "react";
import axios from "axios";
import AddResident from "./Added/AddResident";

import {
  Button,
  Card,
  Input,
  Loop,
  Page,
  ProfileCard,
  Table,
  Text,
  Tick,
} from "../../lib";
import DeleteResident, { SetResidentId } from "./Added/DeleteResident";
import EditResident, { SetResidentInfo } from "./Added/EditResident";

export default function ManageResidents() {
  useEffect(() => {
    Tick(RecognizeFilteringMethod);
  }, []);

  const [data, sendData] = useState({});

  const SearchResidents = async (keyword) => {
    let search = {
      resident_id: keyword,
      resident_firstname: keyword,
      resident_middlename: keyword,
      resident_lastname: keyword,
      resident_occupation: keyword,
    };

    const res = await axios.post(
      "http://localhost:4435/residents/search",
      search
    );
    sendData(res.data);
  };

  const OrderById = async () => {
    const res = await axios.get("http://localhost:4435/residents");
    sendData(res.data);
  };

  const RecognizeFilteringMethod = () => {
    const search = document.querySelector("#searchResident");

    if (search.value !== "") return SearchResidents(search.value);

    return OrderById();
  };

  return (
    <>
      <AddResident />
      <EditResident />
      <DeleteResident />

      <Table.Row>
        <Table.Col props="col-sm-12 mb-5 flex justify-content-end">
          <Input id="searchResident" label="Search residents" props="w-1/2" />
          <Button
            label="add"
            props="btn-primary mx-3 px-5 material-icons"
            toggle="modal"
            target="addResident"
          />
        </Table.Col>

        <Table.Col>
          <table className="table bg-transparent">
            <thead>
              <th>#</th>
              <th>Firstname</th>
              <th>Middlename</th>
              <th>Lastname</th>
              <th>Birthday</th>
              <th>Sex</th>
              <th>Occupation</th>
              <th>Civil Status</th>
              <th>Actions</th>
            </thead>

            <tbody>
              <Loop repeat={data.length}>
                {(index) => (
                  <tr key={index} scope="row" className="bg-transparent">
                    <td className="bg-transparent">
                      {data[index].resident_id}
                    </td>
                    <td className="bg-transparent">
                      {data[index].resident_firstname}
                    </td>
                    <td className="bg-transparent">
                      {data[index].resident_middlename}
                    </td>
                    <td className="bg-transparent">
                      {data[index].resident_lastname}
                    </td>
                    <td className="bg-transparent">
                      {data[index].resident_birthday}
                    </td>
                    <td className="bg-transparent">
                      {data[index].resident_sex}
                    </td>
                    <td className="bg-transparent">
                      {data[index].resident_occupation}
                    </td>
                    <td className="bg-transparent">
                      {data[index].resident_civil_status}
                    </td>
                    <td className="bg-transparent">
                      <Button
                        label="edit"
                        props="btn-info material-icons mr-3"
                        toggle="modal"
                        target="editResident"
                        click={() => SetResidentInfo(
                          data[index].resident_firstname,
                          data[index].resident_middlename,
                          data[index].resident_lastname,
                          data[index].resident_birthday,
                          data[index].resident_sex,
                          data[index].resident_occupation,
                          data[index].resident_civil_status,
                          data[index].resident_id
                        )}
                      />
                      <Button
                        label="delete"
                        toggle="modal"
                        target="deleteUser"
                        click={() => SetResidentId(data[index].resident_id)}
                        props="btn-danger material-icons"
                      />
                    </td>
                  </tr>
                )}
              </Loop>
            </tbody>
          </table>
        </Table.Col>
      </Table.Row>
    </>
  );
}
