import axios from "axios";
export default function Notify(messageXYZ, typeXYZ) {
    let data = {
        message: messageXYZ,
        type: typeXYZ,
        creation: 20030101,
    };

    axios.post("http://localhost:4435/notifications/post", data);
}


