export default function Documents() {
    return(
        <h1>Docs</h1>
    )
}